int a;

int list list_filter (int a) {
   if (a > 2) return a;
}

float list list_map (int a) {
   return a / 2.0;
}

int main() {
   int list list1;
   list1 = NIL;
   float list list2;
   list2 = NIL;
   1 : list1;
   2 : list1;
   1 + 2 : list2;
   list_filter >> list_filter >> list1;
   return 0;
}