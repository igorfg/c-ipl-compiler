int main() {
    int a;
    int b;
    int c;

    a = 1;
    b = 2;

    a = a + - b;

    c = a > b && a <= b && a == a && a != b && !a || !b;
    c = a + b / c - a * (b + c) / (a-c);

    return 0;
}