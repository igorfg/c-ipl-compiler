/* This comment should be ignored */
double f;
long int i;

void main() {
    f = 0.1;
    @read(i);
    #read(f);

    /* neverending comment 


    return 0;
}
