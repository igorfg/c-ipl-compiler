int a = 6;

int main() {
    1 + 3 * ( + 4;
    if else;
    i = = 4;
    int j;
    j
    #lex_error;

}
