int a;
int b;

int main() (
    int list c;
    if if;
    int spaced var;
);

untyped_func_declaration() {}