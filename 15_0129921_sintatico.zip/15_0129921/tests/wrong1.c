int a;
int b;

untyped_func_declaration() {}

int main() {
    int list c;
    int spaced var;
    if if;
    ;;
);
