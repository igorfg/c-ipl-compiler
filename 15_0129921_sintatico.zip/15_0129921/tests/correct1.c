float func1() {
  int a;
  int b;
  b = a+2;
  return 2;
}

int func2() {
  int i;
  for (i = 0; i < 7; i = i + 1) {
    (1+2)*4;
    writeln("Hi guys\n");
    write("this is working :)\n");
  }
  return 0;
}

int main () {
  int z;
  z = func1();
  return 0;
}