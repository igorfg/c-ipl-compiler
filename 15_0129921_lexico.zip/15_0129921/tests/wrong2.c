
int i;

int main() {
    i = $;

    write('single quotes are not allowed');
    write("double quotes are not closing);
    write("multi line
    string");
    retrun 0;
}